import { z } from 'zod';

export const inquirySchema = z.object({
    name: z.string().min(1, 'Name is required'),
    email: z.string().email('Invalid email format'),
    company: z.string().optional(),
    message: z.string().min(5, 'Message must be at least 5 characters'),
    sourcePage: z.string().optional(),
});

export const waitlistSchema = z.object({
    email: z.string().email('Invalid email format'),
    name: z.string().optional(),
    meta: z.record(z.any()).optional(),
    event: z.enum(['signup', 'login', 'visit']).optional().default('signup'),
});

export type InquiryInput = z.infer<typeof inquirySchema>;
export type WaitlistInput = z.infer<typeof waitlistSchema>;
